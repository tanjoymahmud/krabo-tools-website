KRABO TOOLS — FREE ONE-PAGE WEBSITE

Files:
- index.html: the website
- logo.jpg: your supplied company logo
- cover-banner.png: the Facebook cover artwork used in the website banner

Preview:
Open index.html in a web browser.

Free publishing:
1. Create a free GitHub account at https://github.com/
2. Create a new public repository named: krabo-tools-website
3. Upload all three files (index.html, logo.jpg, cover-banner.png) to the repository root.
4. Open repository Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. GitHub will provide a free website address, usually:
   https://YOUR-USERNAME.github.io/krabo-tools-website/

Notes:
- No hosting fee is required for a public GitHub Pages site.
- A custom .com domain is optional and normally costs money.
- The inquiry form uses the visitor's email application (mailto); it does not store submissions online.
- Please verify company details, products, phone numbers and email before publishing.
